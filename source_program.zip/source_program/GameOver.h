#pragma once


void Over_Initialize();


void Over_Finalize();

//�X�V
void Over_Update();

//�`��
void Over_Draw();
