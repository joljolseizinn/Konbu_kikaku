#pragma once

//�X�V
void Menu_Update();
void sound();
void title_Initialize();
void title_Finalize();

//�`��
void Menu_Draw();
