#pragma once


void Clear_Initialize();

void Clear_Finalize();
//�X�V
void Clear_Update();

//�`��
void Clear_Draw();
