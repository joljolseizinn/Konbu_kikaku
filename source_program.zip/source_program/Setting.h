#pragma once

void Setting_Initialize();

void Setting_Finalize();

void Setting_Update();

void Setting_Draw();
